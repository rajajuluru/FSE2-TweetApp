package com.example.demo.student;

public enum Gender {
    MALE,
    FEMALE,
    OTHER
}
